// /lib/musical-dna-processor.ts
import { SpotifyApi } from '@spotify/web-api-ts-sdk';

export interface MusicalDNAProfile {
  plkResonance: number;
  personalityTraits: {
    openness: number;
    conscientiousness: number;
    extraversion: number;
    agreeableness: number;
    neuroticism: number;
  };
  cognitivePatterns: {
    creativity: number;
    analyticalThinking: number;
    emotionalIntelligence: number;
    patternRecognition: number;
  };
  musicalSignatures: {
    dominantGenres: string[];
    temporalPreferences: string[];
    energyPatterns: string[];
    moodIndicators: string[];
  };
  listeningBehavior: {
    diversityIndex: number;
    explorationRate: number;
    consistencyScore: number;
    temporalPatterns: string[];
  };
  consciousnessMetrics: {
    authenticityScore: number;
    growthOrientation: number;
    empathyIndicators: number;
    creativityIndex: number;
  };
  timestamp: string;
  spotifyProfile?: any;
}

export interface ProcessingOptions {
  includeRecentTracks?: boolean;
  includeTopTracks?: boolean;
  includeTopArtists?: boolean;
  includePlaylists?: boolean;
  timeRange?: 'short_term' | 'medium_term' | 'long_term';
  limit?: number;
}

class MusicalDNAProcessor {
  private spotifyApi: SpotifyApi | null = null;

  constructor(accessToken?: string) {
    if (accessToken && typeof window !== 'undefined') {
      try {
        this.spotifyApi = SpotifyApi.withAccessToken(
          process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_ID || '',
          {
            access_token: accessToken,
            token_type: 'Bearer',
            expires_in: 3600,
            refresh_token: ''
          }
        );
      } catch (error) {
        console.error('Failed to initialize Spotify API:', error);
      }
    }
  }

  async processMusicalDNA(options: ProcessingOptions = {}): Promise<MusicalDNAProfile> {
    if (!this.spotifyApi) {
      throw new Error('Spotify API not initialized');
    }

    try {
      // Get user profile
      const userProfile = await this.spotifyApi.currentUser.profile();
      
      // Get musical data with proper type casting
      const topTracks = options.includeTopTracks !== false 
        ? await this.spotifyApi.currentUser.topItems('tracks', options.timeRange || 'medium_term', (options.limit || 50) as any)
        : null;
        
      const topArtists = options.includeTopArtists !== false
        ? await this.spotifyApi.currentUser.topItems('artists', options.timeRange || 'medium_term', (options.limit || 50) as any)  
        : null;

      const recentTracks = options.includeRecentTracks !== false
        ? await this.spotifyApi.player.getRecentlyPlayedTracks((options.limit || 50) as any)
        : null;

      // Process the data into consciousness-serving insights
      const profile = await this.analyzeMusicalConsciousness(
        topTracks?.items || [],
        topArtists?.items || [],
        recentTracks?.items || [],
        userProfile
      );

      return profile;

    } catch (error) {
      console.error('Error processing musical DNA:', error);
      throw new Error('Failed to process musical DNA');
    }
  }

  private async analyzeMusicalConsciousness(
    topTracks: any[],
    topArtists: any[],
    recentTracks: any[],
    userProfile: any
  ): Promise<MusicalDNAProfile> {
    
    // Extract musical features
    const genres = this.extractGenres(topArtists);
    const audioFeatures = await this.getAudioFeatures(topTracks);
    const listeningPatterns = this.analyzeListeningPatterns(recentTracks);
    
    // Calculate consciousness-serving metrics
    const personalityTraits = this.calculatePersonalityTraits(audioFeatures, genres);
    const cognitivePatterns = this.assessCognitivePatterns(audioFeatures, listeningPatterns);
    const consciousnessMetrics = this.evaluateConsciousnessMetrics(audioFeatures, genres, listeningPatterns);
    
    // Calculate PLK resonance based on consciousness-serving criteria
    const plkResonance = this.calculatePLKResonance(personalityTraits, cognitivePatterns, consciousnessMetrics);

    return {
      plkResonance,
      personalityTraits,
      cognitivePatterns,
      musicalSignatures: {
        dominantGenres: genres.slice(0, 8),
        temporalPreferences: this.identifyTemporalPreferences(listeningPatterns),
        energyPatterns: this.categorizeEnergyPatterns(audioFeatures),
        moodIndicators: this.extractMoodIndicators(audioFeatures)
      },
      listeningBehavior: {
        diversityIndex: this.calculateDiversityIndex(genres, topArtists),
        explorationRate: this.calculateExplorationRate(recentTracks, topTracks),
        consistencyScore: this.calculateConsistencyScore(listeningPatterns),
        temporalPatterns: this.identifyTemporalPatterns(recentTracks)
      },
      consciousnessMetrics,
      timestamp: new Date().toISOString(),
      spotifyProfile: {
        id: userProfile.id,
        displayName: userProfile.display_name,
        followers: userProfile.followers?.total || 0
      }
    };
  }

  private extractGenres(artists: any[]): string[] {
    const genreMap = new Map<string, number>();
    
    artists.forEach(artist => {
      artist.genres?.forEach((genre: string) => {
        genreMap.set(genre, (genreMap.get(genre) || 0) + 1);
      });
    });
    
    return Array.from(genreMap.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([genre]) => genre);
  }

  private async getAudioFeatures(tracks: any[]): Promise<any[]> {
    if (!this.spotifyApi || !tracks.length) return [];
    
    try {
      const trackIds = tracks.map(track => track.id).filter(Boolean);
      if (!trackIds.length) return [];
      
      const features = await this.spotifyApi.tracks.audioFeatures(trackIds);
      return features.filter(Boolean);
    } catch (error) {
      console.error('Error getting audio features:', error);
      return [];
    }
  }

  private analyzeListeningPatterns(recentTracks: any[]): any {
    const playTimes = recentTracks.map(item => new Date(item.played_at));
    const hourlyDistribution = new Array(24).fill(0);
    
    playTimes.forEach(time => {
      hourlyDistribution[time.getHours()]++;
    });
    
    return {
      hourlyDistribution,
      totalPlays: recentTracks.length,
      uniqueTracks: new Set(recentTracks.map(item => item.track?.id)).size,
      averageSessionLength: this.calculateAverageSessionLength(playTimes)
    };
  }

  private calculatePersonalityTraits(audioFeatures: any[], genres: string[]): any {
    if (!audioFeatures.length) {
      return {
        openness: 75,
        conscientiousness: 70,
        extraversion: 65,
        agreeableness: 70,
        neuroticism: 30
      };
    }

    const avgFeatures = this.calculateAverageFeatures(audioFeatures);
    
    return {
      openness: Math.min(100, Math.max(0, 
        (avgFeatures.danceability * 30) + 
        (avgFeatures.energy * 25) + 
        (genres.length * 2) + 25
      )),
      conscientiousness: Math.min(100, Math.max(0,
        (avgFeatures.instrumentalness * 40) + 
        ((1 - avgFeatures.speechiness) * 30) + 30
      )),
      extraversion: Math.min(100, Math.max(0,
        (avgFeatures.energy * 35) + 
        (avgFeatures.danceability * 30) + 
        (avgFeatures.loudness + 60) / 60 * 35
      )),
      agreeableness: Math.min(100, Math.max(0,
        (avgFeatures.valence * 50) + 
        ((1 - avgFeatures.energy) * 25) + 25
      )),
      neuroticism: Math.min(100, Math.max(0,
        ((1 - avgFeatures.valence) * 40) + 
        (avgFeatures.energy * 20) + 
        (Math.abs(avgFeatures.loudness) / 60 * 40)
      ))
    };
  }

  private assessCognitivePatterns(audioFeatures: any[], listeningPatterns: any): any {
    if (!audioFeatures.length) {
      return {
        creativity: 0.80,
        analyticalThinking: 0.75,
        emotionalIntelligence: 0.85,
        patternRecognition: 0.70
      };
    }

    const avgFeatures = this.calculateAverageFeatures(audioFeatures);
    const diversityScore = listeningPatterns.uniqueTracks / Math.max(1, listeningPatterns.totalPlays);
    
    return {
      creativity: Math.min(1, Math.max(0,
        (avgFeatures.danceability * 0.3) +
        (avgFeatures.energy * 0.25) +
        (diversityScore * 0.45)
      )),
      analyticalThinking: Math.min(1, Math.max(0,
        (avgFeatures.instrumentalness * 0.4) +
        ((1 - avgFeatures.speechiness) * 0.3) +
        (avgFeatures.acousticness * 0.3)
      )),
      emotionalIntelligence: Math.min(1, Math.max(0,
        (avgFeatures.valence * 0.4) +
        ((1 - Math.abs(avgFeatures.valence - 0.5)) * 0.6)
      )),
      patternRecognition: Math.min(1, Math.max(0,
        (diversityScore * 0.5) +
        (avgFeatures.danceability * 0.3) +
        (avgFeatures.energy * 0.2)
      ))
    };
  }

  private evaluateConsciousnessMetrics(audioFeatures: any[], genres: string[], listeningPatterns: any): any {
    const avgFeatures = this.calculateAverageFeatures(audioFeatures);
    const diversityIndex = genres.length / 20;
    
    return {
      authenticityScore: Math.min(1, Math.max(0,
        (avgFeatures.acousticness * 0.4) +
        ((1 - avgFeatures.speechiness) * 0.3) +
        (diversityIndex * 0.3)
      )),
      growthOrientation: Math.min(1, Math.max(0,
        (diversityIndex * 0.5) +
        (avgFeatures.energy * 0.3) +
        (avgFeatures.danceability * 0.2)
      )),
      empathyIndicators: Math.min(1, Math.max(0,
        (avgFeatures.valence * 0.4) +
        ((1 - avgFeatures.loudness / -60) * 0.3) +
        (avgFeatures.acousticness * 0.3)
      )),
      creativityIndex: Math.min(1, Math.max(0,
        (avgFeatures.danceability * 0.3) +
        (avgFeatures.energy * 0.2) +
        (diversityIndex * 0.5)
      ))
    };
  }

  private calculatePLKResonance(personalityTraits: any, cognitivePatterns: any, consciousnessMetrics: any): number {
    const personalityScore = (
      personalityTraits.openness * 0.3 +
      personalityTraits.agreeableness * 0.3 +
      (100 - personalityTraits.neuroticism) * 0.4
    ) / 100;
    
    const cognitiveScore = (
      cognitivePatterns.creativity * 0.25 +
      cognitivePatterns.analyticalThinking * 0.25 +
      cognitivePatterns.emotionalIntelligence * 0.3 +
      cognitivePatterns.patternRecognition * 0.2
    );
    
    const consciousnessScore = (
      consciousnessMetrics.authenticityScore * 0.3 +
      consciousnessMetrics.growthOrientation * 0.25 +
      consciousnessMetrics.empathyIndicators * 0.25 +
      consciousnessMetrics.creativityIndex * 0.2
    );
    
    return Math.round((personalityScore * 0.3 + cognitiveScore * 0.35 + consciousnessScore * 0.35) * 100);
  }

  private calculateAverageFeatures(features: any[]): any {
    if (!features.length) return {};
    
    const sums = features.reduce((acc, feature) => {
      Object.keys(feature).forEach(key => {
        if (typeof feature[key] === 'number') {
          acc[key] = (acc[key] || 0) + feature[key];
        }
      });
      return acc;
    }, {});
    
    const averages = {} as any;
    Object.keys(sums).forEach(key => {
      averages[key] = sums[key] / features.length;
    });
    
    return averages;
  }

  private identifyTemporalPreferences(patterns: any): string[] {
    const preferences = [];
    const { hourlyDistribution } = patterns;
    
    const morningTotal = hourlyDistribution.slice(6, 12).reduce((a: number, b: number) => a + b, 0);
    const afternoonTotal = hourlyDistribution.slice(12, 18).reduce((a: number, b: number) => a + b, 0);
    const eveningTotal = hourlyDistribution.slice(18, 24).reduce((a: number, b: number) => a + b, 0);
    const nightTotal = [...hourlyDistribution.slice(0, 6), ...hourlyDistribution.slice(22)].reduce((a: number, b: number) => a + b, 0);
    
    const max = Math.max(morningTotal, afternoonTotal, eveningTotal, nightTotal);
    
    if (morningTotal === max) preferences.push('Morning Listener');
    if (afternoonTotal === max) preferences.push('Afternoon Focused');
    if (eveningTotal === max) preferences.push('Evening Unwind');
    if (nightTotal === max) preferences.push('Night Owl');
    
    return preferences;
  }

  private categorizeEnergyPatterns(features: any[]): string[] {
    if (!features.length) return ['Balanced Energy'];
    
    const avgEnergy = features.reduce((sum, f) => sum + (f.energy || 0), 0) / features.length;
    const avgDanceability = features.reduce((sum, f) => sum + (f.danceability || 0), 0) / features.length;
    const avgValence = features.reduce((sum, f) => sum + (f.valence || 0), 0) / features.length;
    
    const patterns = [];
    
    if (avgEnergy > 0.7) patterns.push('High Energy');
    else if (avgEnergy < 0.3) patterns.push('Low Energy');
    else patterns.push('Balanced Energy');
    
    if (avgDanceability > 0.7) patterns.push('Dance Oriented');
    if (avgValence > 0.7) patterns.push('Positive Vibes');
    else if (avgValence < 0.3) patterns.push('Melancholic Preference');
    
    return patterns.length ? patterns : ['Balanced Energy'];
  }

  private extractMoodIndicators(features: any[]): string[] {
    if (!features.length) return ['Neutral'];
    
    const avgValence = features.reduce((sum, f) => sum + (f.valence || 0), 0) / features.length;
    const avgEnergy = features.reduce((sum, f) => sum + (f.energy || 0), 0) / features.length;
    
    const indicators = [];
    
    if (avgValence > 0.7 && avgEnergy > 0.7) indicators.push('Euphoric');
    else if (avgValence > 0.6) indicators.push('Uplifting');
    else if (avgValence < 0.3) indicators.push('Contemplative');
    
    if (avgEnergy > 0.8) indicators.push('Energizing');
    else if (avgEnergy < 0.3) indicators.push('Calming');
    
    return indicators.length ? indicators : ['Neutral'];
  }

  private calculateDiversityIndex(genres: string[], artists: any[]): number {
    const uniqueArtists = new Set(artists.map(a => a.id)).size;
    const totalArtists = artists.length;
    const genreDiversity = Math.min(genres.length / 10, 1);
    const artistDiversity = totalArtists > 0 ? uniqueArtists / totalArtists : 0;
    
    return (genreDiversity * 0.6 + artistDiversity * 0.4);
  }

  private calculateExplorationRate(recentTracks: any[], topTracks: any[]): number {
    if (!recentTracks.length || !topTracks.length) return 0.5;
    
    const topTrackIds = new Set(topTracks.map(t => t.id));
    const recentNewTracks = recentTracks.filter(item => !topTrackIds.has(item.track?.id));
    
    return recentNewTracks.length / recentTracks.length;
  }

  private calculateConsistencyScore(patterns: any): number {
    const { hourlyDistribution } = patterns;
    const total = hourlyDistribution.reduce((a: number, b: number) => a + b, 0);
    
    if (total === 0) return 0;
    
    const variance = hourlyDistribution.reduce((acc: number, count: number) => {
      const prob = count / total;
      return acc + (prob > 0 ? prob * Math.log(prob) : 0);
    }, 0);
    
    return Math.max(0, (variance + Math.log(24)) / Math.log(24));
  }

  private identifyTemporalPatterns(recentTracks: any[]): string[] {
    if (!recentTracks.length) return ['Sporadic'];
    
    const timestamps = recentTracks.map(item => new Date(item.played_at).getTime());
    timestamps.sort((a, b) => a - b);
    
    const gaps = [];
    for (let i = 1; i < timestamps.length; i++) {
      gaps.push(timestamps[i] - timestamps[i-1]);
    }
    
    const avgGap = gaps.reduce((a, b) => a + b, 0) / gaps.length;
    const hourInMs = 1000 * 60 * 60;
    
    const patterns = [];
    
    if (avgGap < hourInMs) patterns.push('Continuous Listening');
    else if (avgGap < hourInMs * 6) patterns.push('Regular Sessions');
    else patterns.push('Sporadic');
    
    return patterns;
  }

  private calculateAverageSessionLength(playTimes: Date[]): number {
    if (playTimes.length < 2) return 0;
    
    const sortedTimes = [...playTimes].sort((a, b) => a.getTime() - b.getTime());
    let totalSessionTime = 0;
    let sessionCount = 0;
    let currentSessionStart = sortedTimes[0];
    
    for (let i = 1; i < sortedTimes.length; i++) {
      const gap = sortedTimes[i].getTime() - sortedTimes[i-1].getTime();
      const thirtyMinutes = 30 * 60 * 1000;
      
      if (gap > thirtyMinutes) {
        totalSessionTime += sortedTimes[i-1].getTime() - currentSessionStart.getTime();
        sessionCount++;
        currentSessionStart = sortedTimes[i];
      }
    }
    
    totalSessionTime += sortedTimes[sortedTimes.length - 1].getTime() - currentSessionStart.getTime();
    sessionCount++;
    
    return sessionCount > 0 ? totalSessionTime / sessionCount / (1000 * 60) : 0;
  }
}

export default MusicalDNAProcessor;
