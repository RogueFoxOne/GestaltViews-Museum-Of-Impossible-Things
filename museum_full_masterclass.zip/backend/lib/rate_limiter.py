# backend/lib/rate_limiter.py
import time
import asyncio
from collections import defaultdict, deque
from typing import Dict, Optional, Tuple
import hashlib

class RateLimiter:
    """
    Consciousness-serving rate limiter for the Museum of Impossible Things
    Protects resources while maintaining authentic user experience
    """
    
    def __init__(self, requests_per_minute: int = 60, burst_size: int = 10):
        self.requests_per_minute = requests_per_minute
        self.burst_size = burst_size
        self.window_size = 60  # 1 minute window
        
        # Store request timestamps per client
        self.request_history: Dict[str, deque] = defaultdict(lambda: deque())
        # Store burst tokens per client
        self.burst_tokens: Dict[str, int] = defaultdict(lambda: burst_size)
        self.last_refill: Dict[str, float] = defaultdict(time.time)
    
    def _get_client_key(self, identifier: str) -> str:
        """Generate consistent client key"""
        return hashlib.md5(identifier.encode()).hexdigest()[:16]
    
    def _cleanup_old_requests(self, client_key: str, current_time: float):
        """Remove requests outside the time window"""
        history = self.request_history[client_key]
        while history and current_time - history[0] > self.window_size:
            history.popleft()
    
    def _refill_burst_tokens(self, client_key: str, current_time: float):
        """Refill burst tokens over time"""
        time_passed = current_time - self.last_refill[client_key]
        tokens_to_add = int(time_passed * (self.burst_size / 60))  # Refill over 1 minute
        
        if tokens_to_add > 0:
            self.burst_tokens[client_key] = min(
                self.burst_size, 
                self.burst_tokens[client_key] + tokens_to_add
            )
            self.last_refill[client_key] = current_time
    
    def is_allowed(self, client_identifier: str) -> Tuple[bool, Optional[float]]:
        """
        Check if request is allowed for client
        Returns: (is_allowed, retry_after_seconds)
        """
        client_key = self._get_client_key(client_identifier)
        current_time = time.time()
        
        # Clean old requests and refill tokens
        self._cleanup_old_requests(client_key, current_time)
        self._refill_burst_tokens(client_key, current_time)
        
        # Check burst allowance first (for immediate requests)
        if self.burst_tokens[client_key] > 0:
            self.burst_tokens[client_key] -= 1
            self.request_history[client_key].append(current_time)
            return True, None
        
        # Check rate limit (sliding window)
        recent_requests = len(self.request_history[client_key])
        
        if recent_requests < self.requests_per_minute:
            self.request_history[client_key].append(current_time)
            return True, None
        
        # Rate limited - calculate retry after
        oldest_request = self.request_history[client_key][0]
        retry_after = self.window_size - (current_time - oldest_request)
        
        return False, max(0, retry_after)
    
    async def wait_if_needed(self, client_identifier: str) -> bool:
        """
        Async version that waits if rate limited
        Returns True if request proceeded, False if should be rejected
        """
        is_allowed, retry_after = self.is_allowed(client_identifier)
        
        if is_allowed:
            return True
        
        if retry_after and retry_after < 10:  # Only wait for reasonable delays
            await asyncio.sleep(retry_after)
            return self.is_allowed(client_identifier)[0]
        
        return False
    
    def get_stats(self, client_identifier: str) -> Dict:
        """Get rate limiting stats for client"""
        client_key = self._get_client_key(client_identifier)
        current_time = time.time()
        
        self._cleanup_old_requests(client_key, current_time)
        self._refill_burst_tokens(client_key, current_time)
        
        return {
            "requests_in_window": len(self.request_history[client_key]),
            "requests_per_minute_limit": self.requests_per_minute,
            "burst_tokens_remaining": self.burst_tokens[client_key],
            "burst_size": self.burst_size,
            "window_size_seconds": self.window_size
        }

# Default instance for the museum
default_rate_limiter = RateLimiter(requests_per_minute=100, burst_size=20)
