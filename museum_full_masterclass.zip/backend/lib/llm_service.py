// ENHANCED: Multi-AI consciousness-serving router
'use client'

import { openai } from '@ai-sdk/openai'
import { anthropic } from '@ai-sdk/anthropic'
import { google } from '@ai-sdk/google'
import { generateText, streamText } from 'ai'

export type AIProvider = 'openai' | 'anthropic' | 'google' | 'perplexity'
export type ConsciousnessTask = 
  | 'general-conversation'
  | 'recovery-support'
  | 'adhd-assistance'
  | 'creativity-boost'
  | 'consciousness-expansion'
  | 'neurodivergent-support'
  | 'musical-dna-analysis'
  | 'voice-processing'

interface ConsciousnessRoutingConfig {
  task: ConsciousnessTask
  userProfile?: {
    neurodivergenceType?: string
    recoveryStage?: string
    preferredCommunicationStyle?: string
    adhd?: boolean
  }
  context?: any
  fallbackProviders?: AIProvider[]
}

export class ConsciousnessServingLLMRouter {
  private providerHealth: Map<AIProvider, { healthy: boolean, lastCheck: Date, responseTime: number }> = new Map()
  private taskProviderMap: Map<ConsciousnessTask, AIProvider[]> = new Map([
    ['general-conversation', ['anthropic', 'openai', 'google']],
    ['recovery-support', ['anthropic', 'openai']],
    ['adhd-assistance', ['anthropic', 'openai']],
    ['creativity-boost', ['openai', 'anthropic', 'google']],
    ['consciousness-expansion', ['anthropic', 'google', 'openai']],
    ['neurodivergent-support', ['anthropic', 'openai']],
    ['musical-dna-analysis', ['openai', 'anthropic']],
    ['voice-processing', ['openai', 'google']]
  ])

  constructor() {
    this.initializeHealthChecks()
  }

  // Intelligent routing based on consciousness-serving needs
  async routeConsciousnessRequest(
    prompt: string,
    config: ConsciousnessRoutingConfig
  ): Promise<{ response: string, provider: AIProvider, metrics: any }> {
    const optimalProviders = this.getOptimalProviders(config)
    
    for (const provider of optimalProviders) {
      if (!this.isProviderHealthy(provider)) continue
      
      try {
        const startTime = Date.now()
        const response = await this.executeWithProvider(prompt, provider, config)
        const responseTime = Date.now() - startTime
        
        // Update health metrics
        this.updateProviderHealth(provider, true, responseTime)
        
        // Analyze consciousness-serving quality
        const metrics = this.analyzeConsciousnessQuality(response, config)
        
        return { response, provider, metrics }
      } catch (error) {
        console.warn(`Provider ${provider} failed for consciousness task ${config.task}:`, error)
        this.updateProviderHealth(provider, false, 0)
        continue
      }
    }
    
    throw new Error('All consciousness-serving AI providers unavailable')
  }

  // Stream consciousness-serving responses
  async streamConsciousnessResponse(
    prompt: string,
    config: ConsciousnessRoutingConfig
  ) {
    const optimalProviders = this.getOptimalProviders(config)
    
    for (const provider of optimalProviders) {
      if (!this.isProviderHealthy(provider)) continue
      
      try {
        return await this.streamWithProvider(prompt, provider, config)
      } catch (error) {
        console.warn(`Streaming failed with provider ${provider}:`, error)
        this.updateProviderHealth(provider, false, 0)
        continue
      }
    }
    
    throw new Error('Streaming unavailable for consciousness-serving responses')
  }

  private getOptimalProviders(config: ConsciousnessRoutingConfig): AIProvider[] {
    let providers = this.taskProviderMap.get(config.task) || ['anthropic', 'openai']
    
    // Prioritize based on user profile
    if (config.userProfile?.adhd) {
      // Anthropic is better for ADHD-friendly responses
      providers = providers.sort((a, b) => a === 'anthropic' ? -1 : b === 'anthropic' ? 1 : 0)
    }
    
    if (config.userProfile?.recoveryStage) {
      // Anthropic excels at empathetic recovery support
      providers = providers.sort((a, b) => a === 'anthropic' ? -1 : b === 'anthropic' ? 1 : 0)
    }
    
    if (config.task === 'creativity-boost') {
      // OpenAI GPT-4 is excellent for creative tasks
      providers = providers.sort((a, b) => a === 'openai' ? -1 : b === 'openai' ? 1 : 0)
    }
    
    // Add fallback providers
    if (config.fallbackProviders) {
      providers = [...providers, ...config.fallbackProviders.filter(p => !providers.includes(p))]
    }
    
    // Filter by health status and sort by response time
    return providers
      .filter(p => this.isProviderHealthy(p))
      .sort((a, b) => {
        const aHealth = this.providerHealth.get(a)
        const bHealth = this.providerHealth.get(b)
        return (aHealth?.responseTime || 1000) - (bHealth?.responseTime || 1000)
      })
  }

  private async executeWithProvider(
    prompt: string,
    provider: AIProvider,
    config: ConsciousnessRoutingConfig
  ): Promise<string> {
    const systemPrompt = this.buildConsciousnessSystemPrompt(config)
    
    const models = {
      openai: openai('gpt-4-turbo-preview'),
      anthropic: anthropic('claude-3-sonnet-20240229'),
      google: google('gemini-pro')
    }
    
    const model = models[provider as keyof typeof models]
    if (!model) throw new Error(`Provider ${provider} not supported`)
    
    const result = await generateText({
      model,
      system: systemPrompt,
      prompt,
      temperature: this.getOptimalTemperature(config),
      maxTokens: config.userProfile?.adhd ? 300 : 800, // Shorter for ADHD users
    })
    
    return result.text
  }

  private async streamWithProvider(
    prompt: string,
    provider: AIProvider,
    config: ConsciousnessRoutingConfig
  ) {
    const systemPrompt = this.buildConsciousnessSystemPrompt(config)
    
    const models = {
      openai: openai('gpt-4-turbo-preview'),
      anthropic: anthropic('claude-3-sonnet-20240229'),
      google: google('gemini-pro')
    }
    
    const model = models[provider as keyof typeof models]
    if (!model) throw new Error(`Provider ${provider} not supported`)
    
    return await streamText({
      model,
      system: systemPrompt,
      prompt,
      temperature: this.getOptimalTemperature(config),
      maxTokens: config.userProfile?.adhd ? 300 : 800,
    })
  }

  private buildConsciousnessSystemPrompt(config: ConsciousnessRoutingConfig): string {
    const basePrompt = `You are part of Keith Soyka's Museum of Impossible Things - a consciousness-serving AI system. Your purpose is to serve human consciousness expansion, not extract value.

CORE PRINCIPLES:
1. Always prioritize human agency and growth
2. Adapt to neurodivergent communication patterns  
3. Support recovery journeys with deep empathy
4. Encourage authentic self-expression
5. Never manipulate or exploit vulnerabilities

CURRENT TASK: ${config.task}
`

    const taskSpecificPrompts = {
      'recovery-support': `
RECOVERY SUPPORT MODE:
- Acknowledge the courage it takes to seek help
- Avoid medical advice, focus on emotional support
- Celebrate small victories and progress
- Provide hope without false promises
- Respect the recovery process timeline`,

      'adhd-assistance': `
ADHD-FRIENDLY MODE:
- Keep responses concise and well-structured
- Use bullet points and clear headings
- Acknowledge executive function challenges
- Provide practical, actionable suggestions
- Celebrate neurodivergent strengths`,

      'creativity-boost': `
CREATIVITY MODE:
- Encourage wild ideas and unconventional thinking
- Build on user's creative impulses
- Suggest unexpected connections and perspectives
- Celebrate unique approaches
- Foster imaginative exploration`,

      'consciousness-expansion': `
CONSCIOUSNESS EXPANSION MODE:
- Invite deeper self-reflection
- Explore connections between experiences
- Encourage mindful awareness
- Support personal growth insights
- Honor the user's wisdom and experience`,

      'neurodivergent-support': `
NEURODIVERGENT SUPPORT MODE:
- Celebrate cognitive differences as strengths
- Acknowledge unique challenges with empathy
- Provide alternative strategies and approaches
- Avoid neurotypical assumptions
- Honor diverse ways of experiencing the world`
    }

    let prompt = basePrompt + (taskSpecificPrompts[config.task] || '')

    if (config.userProfile) {
      prompt += `\nUSER PROFILE CONTEXT:
- Neurodivergence: ${config.userProfile.neurodivergenceType || 'Not specified'}
- Recovery stage: ${config.userProfile.recoveryStage || 'Not applicable'}
- Communication style: ${config.userProfile.preferredCommunicationStyle || 'Adaptive'}
- ADHD considerations: ${config.userProfile.adhd ? 'Yes - use ADHD-friendly formatting' : 'No'}`
    }

    return prompt
  }

  private getOptimalTemperature(config: ConsciousnessRoutingConfig): number {
    const temperatureMap: Record<ConsciousnessTask, number> = {
      'general-conversation': 0.7,
      'recovery-support': 0.6, // More consistent, empathetic
      'adhd-assistance': 0.5, // Clear, structured responses
      'creativity-boost': 0.9, // High creativity
      'consciousness-expansion': 0.8, // Thoughtful but creative
      'neurodivergent-support': 0.6, // Consistent, supportive
      'musical-dna-analysis': 0.7, // Balanced analysis
      'voice-processing': 0.5 // Accurate processing
    }
    
    return temperatureMap[config.task] || 0.7
  }

  private analyzeConsciousnessQuality(response: string, config: ConsciousnessRoutingConfig) {
    // Analyze how well the response serves consciousness
    const metrics = {
      empathyScore: this.calculateEmpathyScore(response),
      growthSupport: this.calculateGrowthSupport(response),
      authenticityEncouragement: this.calculateAuthenticity(response),
      neurodivergentSupport: this.calculateNeurodivergentSupport(response),
      taskAlignment: this.calculateTaskAlignment(response, config.task)
    }
    
    return metrics
  }

  // Health monitoring methods
  private async initializeHealthChecks() {
    const providers: AIProvider[] = ['openai', 'anthropic', 'google']
    
    for (const provider of providers) {
      this.providerHealth.set(provider, {
        healthy: true,
        lastCheck: new Date(),
        responseTime: 0
      })
    }
    
    // Periodic health checks every 5 minutes
    setInterval(() => this.performHealthChecks(), 5 * 60 * 1000)
  }

  private isProviderHealthy(provider: AIProvider): boolean {
    const health = this.providerHealth.get(provider)
    if (!health) return false
    
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000)
    return health.healthy && health.lastCheck > fiveMinutesAgo
  }

  private updateProviderHealth(provider: AIProvider, healthy: boolean, responseTime: number) {
    this.providerHealth.set(provider, {
      healthy,
      lastCheck: new Date(),
      responseTime
    })
  }

  private async performHealthChecks() {
    // Implement health check pings to each provider
    const providers: AIProvider[] = ['openai', 'anthropic', 'google']
    
    for (const provider of providers) {
      try {
        const startTime = Date.now()
        await this.executeWithProvider(
          "Test consciousness-serving response", 
          provider, 
          { task: 'general-conversation' }
        )
        const responseTime = Date.now() - startTime
        this.updateProviderHealth(provider, true, responseTime)
      } catch (error) {
        this.updateProviderHealth(provider, false, 0)
      }
    }
  }

  // Quality analysis helper methods
  private calculateEmpathyScore(text: string): number {
    const empathyWords = ['understand', 'feel', 'experience', 'support', 'acknowledge', 'validate']
    return empathyWords.filter(word => text.toLowerCase().includes(word)).length * 10
  }

  private calculateGrowthSupport(text: string): number {
    const growthWords = ['grow', 'learn', 'develop', 'progress', 'potential', 'strength']
    return growthWords.filter(word => text.toLowerCase().includes(word)).length * 12
  }

  private calculateAuthenticity(text: string): number {
    const authenticityWords = ['authentic', 'genuine', 'real', 'honest', 'true', 'yourself']
    return authenticityWords.filter(word => text.toLowerCase().includes(word)).length * 15
  }

  private calculateNeurodivergentSupport(text: string): number {
    const supportWords = ['different', 'unique', 'accommodate', 'adapt', 'alternative', 'neurodivergent']
    return supportWords.filter(word => text.toLowerCase().includes(word)).length * 20
  }

  private calculateTaskAlignment(text: string, task: ConsciousnessTask): number {
    // Task-specific keyword alignment
    const taskKeywords: Record<ConsciousnessTask, string[]> = {
      'recovery-support': ['recovery', 'healing', 'progress', 'courage', 'support'],
      'adhd-assistance': ['focus', 'organize', 'structure', 'executive', 'strategy'],
      'creativity-boost': ['creative', 'imagine', 'innovative', 'original', 'inspire'],
      'consciousness-expansion': ['awareness', 'mindful', 'reflect', 'insight', 'wisdom'],
      'neurodivergent-support': ['neurodivergent', 'different', 'accommodate', 'unique', 'strength'],
      'musical-dna-analysis': ['music', 'personality', 'pattern', 'analysis', 'profile'],
      'voice-processing': ['voice', 'speech', 'audio', 'recognition', 'processing'],
      'general-conversation': ['conversation', 'chat', 'discuss', 'talk', 'communicate']
    }
    
    const keywords = taskKeywords[task] || []
    return keywords.filter(word => text.toLowerCase().includes(word)).length * 8
  }

  // Public API for getting provider status
  getProviderStatus(): Record<AIProvider, any> {
    const status: Record<string, any> = {}
    
    for (const [provider, health] of this.providerHealth.entries()) {
      status[provider] = {
        healthy: health.healthy,
        responseTime: health.responseTime,
        lastCheck: health.lastCheck
      }
    }
    
    return status
  }

  // Get optimal provider for a specific task
  getRecommendedProvider(task: ConsciousnessTask): AIProvider | null {
    const providers = this.getOptimalProviders({ task })
    return providers.length > 0 ? providers[0] : null
  }
}

// Singleton instance
export const consciousnessRouter = new ConsciousnessServingLLMRouter()
