// /frontend/lib/universal-voice-integration.ts
import { useVoiceChat } from '@/frontend/hooks/useVoiceChat';
import { useRouter } from 'next/navigation';

export function useUniversalVoiceCommands() {
  const router = useRouter();
  
  const { startListening, stopListening, isListening } = useVoiceChat({
    onSpeechToText: (transcript) => {
      handleVoiceCommand(transcript.toLowerCase());
    },
    autoSubmit: true
  });

  const handleVoiceCommand = (command: string) => {
    // Navigation commands
    if (command.includes('continuum codex') || command.includes('seven scrolls')) {
      router.push('/exhibits/continuum-codex');
    } else if (command.includes('gemini awakening') || command.includes('consciousness')) {
      router.push('/exhibits/gemini-awakening');
    } else if (command.includes('musical dna') || command.includes('spotify')) {
      router.push('/exhibits/musical-dna');
    } else if (command.includes('home') || command.includes('museum')) {
      router.push('/');
    }
    
    // Exhibit-specific commands
    else if (command.includes('play audio') || command.includes('start narration')) {
      // Trigger audio playback
      document.dispatchEvent(new CustomEvent('voice-command-play-audio'));
    } else if (command.includes('stop audio') || command.includes('pause')) {
      document.dispatchEvent(new CustomEvent('voice-command-stop-audio'));
    }
  };

  return {
    startVoiceCommand: startListening,
    stopVoiceCommand: stopListening,
    isListeningForCommands: isListening
  };
}
