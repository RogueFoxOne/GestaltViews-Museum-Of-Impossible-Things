// /lib/voice-processor.ts
/**
 * VoiceProcessor - Handles speech recognition and synthesis
 * Uses browser native APIs with proper TypeScript support
 */

interface VoiceProcessorOptions {
  continuous?: boolean;
  interimResults?: boolean;
  language?: string;
  autoStart?: boolean;
}

interface VoiceProcessorEvents {
  onResult?: (transcript: string, isFinal: boolean) => void;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: string) => void;
  onSpeechStart?: () => void;
  onSpeechEnd?: () => void;
}

/**
 * VoiceProcessor class for handling speech recognition and synthesis
 * Uses native browser APIs with proper error handling
 */
export class VoiceProcessor {
  private recognition: any = null;
  private mediaRecorder: MediaRecorder | null = null;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private isListening: boolean = false;
  private isSpeaking: boolean = false;
  private options: VoiceProcessorOptions;
  private events: VoiceProcessorEvents;

  constructor(options: VoiceProcessorOptions = {}, events: VoiceProcessorEvents = {}) {
    this.options = {
      continuous: false,
      interimResults: true,
      language: 'en-US',
      autoStart: false,
      ...options
    };
    this.events = events;
    
    this.initialize();
  }

  /**
   * Initialize the voice processor with browser support detection
   */
  private initialize(): void {
    if (typeof window === 'undefined') {
      console.warn('VoiceProcessor: Window object not available');
      return;
    }

    // Initialize speech recognition
    this.initializeSpeechRecognition();
  }

  /**
   * Initialize speech recognition with proper browser support detection
   */
  private initializeSpeechRecognition(): void {
    try {
      const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      
      if (!SpeechRecognitionClass) {
        console.warn('VoiceProcessor: Speech Recognition not supported in this browser');
        return;
      }

      this.recognition = new SpeechRecognitionClass();
      this.recognition.continuous = this.options.continuous;
      this.recognition.interimResults = this.options.interimResults;
      this.recognition.lang = this.options.language;

      // Set up event handlers
      this.recognition.onstart = () => {
        this.isListening = true;
        this.events.onStart?.();
      };

      this.recognition.onresult = (event: any) => {
        let finalTranscript = '';
        let interimTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          const transcript = result[0].transcript;

          if (result.isFinal) {
            finalTranscript += transcript;
          } else {
            interimTranscript += transcript;
          }
        }

        const fullTranscript = finalTranscript || interimTranscript;
        this.events.onResult?.(fullTranscript, !!finalTranscript);
      };

      this.recognition.onerror = (event: any) => {
        console.error('VoiceProcessor: Speech recognition error:', event.error);
        this.events.onError?.(event.error);
        this.isListening = false;
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.events.onEnd?.();
      };

      this.recognition.onspeechstart = () => {
        this.events.onSpeechStart?.();
      };

      this.recognition.onspeechend = () => {
        this.events.onSpeechEnd?.();
      };

    } catch (error) {
      console.error('VoiceProcessor: Failed to initialize speech recognition:', error);
    }
  }

  /**
   * Check if speech recognition is supported
   */
  public isSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return !!(window as any).SpeechRecognition || !!(window as any).webkitSpeechRecognition;
  }

  /**
   * Start speech recognition
   */
  public async startListening(): Promise<boolean> {
    if (!this.recognition) {
      console.warn('VoiceProcessor: Speech recognition not initialized');
      return false;
    }

    if (this.isListening) {
      console.warn('VoiceProcessor: Already listening');
      return true;
    }

    try {
      this.recognition.start();
      return true;
    } catch (error) {
      console.error('VoiceProcessor: Failed to start listening:', error);
      this.events.onError?.('Failed to start listening');
      return false;
    }
  }

  /**
   * Stop speech recognition
   */
  public stopListening(): void {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
    }
  }

  /**
   * Toggle speech recognition on/off
   */
  public async toggleListening(): Promise<boolean> {
    if (this.isListening) {
      this.stopListening();
      return false;
    } else {
      return await this.startListening();
    }
  }

  /**
   * Check if currently listening
   */
  public getIsListening(): boolean {
    return this.isListening;
  }

  /**
   * Speak text using speech synthesis
   */
  public speakText(text: string, options: {
    rate?: number;
    pitch?: number;
    volume?: number;
    voice?: SpeechSynthesisVoice;
  } = {}): void {
    if (!('speechSynthesis' in window)) {
      console.warn('VoiceProcessor: Speech synthesis not supported');
      return;
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = options.rate ?? 0.9;
    utterance.pitch = options.pitch ?? 1.0;
    utterance.volume = options.volume ?? 0.8;

    if (options.voice) {
      utterance.voice = options.voice;
    }

    utterance.onstart = () => {
      this.isSpeaking = true;
    };

    utterance.onend = () => {
      this.isSpeaking = false;
    };

    utterance.onerror = (error) => {
      console.error('VoiceProcessor: Speech synthesis error:', error);
      this.isSpeaking = false;
    };

    window.speechSynthesis.speak(utterance);
  }

  /**
   * Stop current speech synthesis
   */
  public stopSpeaking(): void {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.isSpeaking = false;
    }
  }

  /**
   * Check if currently speaking
   */
  public getIsSpeaking(): boolean {
    return this.isSpeaking;
  }

  /**
   * Get available voices for speech synthesis
   */
  public getAvailableVoices(): SpeechSynthesisVoice[] {
    if ('speechSynthesis' in window) {
      return window.speechSynthesis.getVoices();
    }
    return [];
  }

  /**
   * Initialize audio visualization (optional) - FIXED NULL CHECKS!
   */
  public async initializeAudioVisualization(): Promise<boolean> {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      this.audioContext = new ((window as any).AudioContext || (window as any).webkitAudioContext)();
      
      // ✅ FIXED: Add null check here!
      if (!this.audioContext) {
        console.error('VoiceProcessor: Failed to create AudioContext');
        return false;
      }
      
      const source = this.audioContext.createMediaStreamSource(stream);
      
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 256;
      source.connect(this.analyser);

      return true;
    } catch (error) {
      console.error('VoiceProcessor: Failed to initialize audio visualization:', error);
      return false;
    }
  }

  /**
   * Get audio level for visualization (0-1)
   */
  public getAudioLevel(): number {
    if (!this.analyser) return 0;

    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(dataArray);
    
    const average = dataArray.reduce((acc, val) => acc + val, 0) / dataArray.length;
    return average / 255;
  }

  /**
   * Clean up resources
   */
  public cleanup(): void {
    this.stopListening();
    this.stopSpeaking();
    
    if (this.recognition) {
      this.recognition.abort();
      this.recognition = null;
    }

    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close();
      this.audioContext = null;
    }

    this.analyser = null;
    this.mediaRecorder = null;
    this.isListening = false;
    this.isSpeaking = false;
  }

  /**
   * Update options
   */
  public updateOptions(newOptions: Partial<VoiceProcessorOptions>): void {
    this.options = { ...this.options, ...newOptions };
    
    if (this.recognition) {
      this.recognition.continuous = this.options.continuous;
      this.recognition.interimResults = this.options.interimResults;
      this.recognition.lang = this.options.language;
    }
  }

  /**
   * Update event handlers
   */
  public updateEvents(newEvents: Partial<VoiceProcessorEvents>): void {
    this.events = { ...this.events, ...newEvents };
  }
}

export default VoiceProcessor;
