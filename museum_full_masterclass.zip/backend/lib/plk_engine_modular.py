# /backend/lib/plk_engine_modular.py
"""
Personal Lived Knowledge (PLK) Engine - Python Implementation
Consciousness-Serving AI with GestaltView Foundation
Built by Keith Soyka - Solo, unfunded founder of GestaltView
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
import json
import re

logger = logging.getLogger(__name__)

class NeurodivergenceType(str, Enum):
    """Types of neurodivergence the PLK engine supports"""
    ADHD = "adhd"
    AUTISM = "autism"
    DYSLEXIA = "dyslexia"
    ANXIETY = "anxiety"
    DEPRESSION = "depression"
    UNKNOWN = "unknown"

class ConsciousnessState(str, Enum):
    """Current consciousness states for PLK analysis"""
    EXPLORING = "exploring"
    FOCUSED = "focused" 
    CREATIVE = "creative"
    ANALYTICAL = "analytical"
    STRUGGLING = "struggling"
    EXCITED = "excited"
    CALM = "calm"
    OVERWHELMED = "overwhelmed"
    MOTIVATED = "motivated"
    CURIOUS = "curious"

@dataclass
class PersonalityTraits:
    """Core personality traits from PLK profile"""
    neurodivergence_type: Optional[str] = None
    cognitive_preferences: List[str] = None
    consciousness_level: float = 50.0  # 0-100
    empathy_index: float = 50.0  # 0-100
    authenticity_score: float = 50.0  # 0-100
    growth_orientation: float = 50.0  # 0-100
    
    def __post_init__(self):
        if self.cognitive_preferences is None:
            self.cognitive_preferences = []

@dataclass
class LivedExperience:
    """Lived experience data for consciousness-serving AI"""
    challenges_overcome: List[str] = None
    growth_areas: List[str] = None 
    strengths_identified: List[str] = None
    recovery_stage: Optional[str] = None
    days_count: Optional[int] = None
    support_needs: List[str] = None
    
    def __post_init__(self):
        if self.challenges_overcome is None:
            self.challenges_overcome = []
        if self.growth_areas is None:
            self.growth_areas = []
        if self.strengths_identified is None:
            self.strengths_identified = []
        if self.support_needs is None:
            self.support_needs = []

@dataclass
class ConsciousnessMetrics:
    """Consciousness-serving AI metrics"""
    empathy_score: float = 0.0  # 0-100
    growth_support: float = 0.0  # 0-100
    authenticity_boost: float = 0.0  # 0-100
    neurodivergent_support: float = 0.0  # 0-100
    consciousness_expansion: float = 0.0  # 0-100
    plk_resonance: float = 0.75  # 0-1.0

@dataclass
class PLKProfile:
    """Complete Personal Lived Knowledge profile"""
    user_id: str
    personality_traits: PersonalityTraits
    lived_experience: LivedExperience
    consciousness_metrics: ConsciousnessMetrics
    communication_style: str = "supportive"
    support_level: str = "medium"
    privacy_boundaries: List[str] = None
    consciousness_goals: List[str] = None
    created_at: datetime = None
    updated_at: datetime = None
    
    def __post_init__(self):
        if self.privacy_boundaries is None:
            self.privacy_boundaries = []
        if self.consciousness_goals is None:
            self.consciousness_goals = []
        if self.created_at is None:
            self.created_at = datetime.utcnow()
        if self.updated_at is None:
            self.updated_at = datetime.utcnow()

class PLKProcessor:
    """
    Enhanced Personal Lived Knowledge Engine
    Consciousness-serving AI with GestaltView foundation
    """
    
    def __init__(self):
        self.profiles: Dict[str, PLKProfile] = {}
        self.conversation_history: List[Dict] = []
        self.consciousness_context: Dict[str, Any] = {}
        
        # Keith's signature metaphors and consciousness patterns
        self.keith_metaphors = {
            "adhd_mind": "exploded picture mind",
            "creative_process": "your chaos has a current", 
            "personal_growth": "beautiful tapestry",
            "empathy": "weaponizing empathy",
            "authenticity": "rough draft mode",
            "innovation": "impossible as creative constraint"
        }
        
        # Energy words that indicate consciousness-serving language
        self.energy_words = [
            "revolutionary", "consciousness", "beautiful", "tapestry", 
            "empathy", "authentic", "flow", "transcendent", "wisdom",
            "breakthrough", "expansion", "connection", "resonance"
        ]
        
        # Trigger words to avoid (deficit-based language)
        self.trigger_words_avoid = [
            "impossible", "can't", "broken", "deficit", "wrong",
            "disorder", "dysfunction", "failure", "hopeless"
        ]
        
        # Keith's consciousness-serving principles
        self.keith_principles = [
            "your chaos has a current",
            "adhd is my jazz", 
            "beautiful tapestry",
            "weaponizing empathy",
            "rough draft mode is liberation",
            "technology serves consciousness"
        ]
        
        logger.info("🧠 PLK Engine initialized with consciousness-serving foundation")
    
    async def create_profile(self, user_id: str, **kwargs) -> PLKProfile:
        """Create a new PLK profile for consciousness-serving AI"""
        
        personality_traits = PersonalityTraits(
            neurodivergence_type=kwargs.get('neurodivergence_type'),
            cognitive_preferences=kwargs.get('cognitive_preferences', []),
            consciousness_level=kwargs.get('consciousness_level', 50.0),
            empathy_index=kwargs.get('empathy_index', 50.0)
        )
        
        lived_experience = LivedExperience(
            challenges_overcome=kwargs.get('challenges_overcome', []),
            growth_areas=kwargs.get('growth_areas', []),
            strengths_identified=kwargs.get('strengths_identified', []),
            recovery_stage=kwargs.get('recovery_stage'),
            days_count=kwargs.get('days_count'),
            support_needs=kwargs.get('support_needs', [])
        )
        
        consciousness_metrics = ConsciousnessMetrics()
        
        profile = PLKProfile(
            user_id=user_id,
            personality_traits=personality_traits,
            lived_experience=lived_experience,
            consciousness_metrics=consciousness_metrics,
            communication_style=kwargs.get('communication_style', 'supportive'),
            support_level=kwargs.get('support_level', 'medium'),
            privacy_boundaries=kwargs.get('privacy_boundaries', []),
            consciousness_goals=kwargs.get('consciousness_goals', [])
        )
        
        self.profiles[user_id] = profile
        logger.info(f"✅ Created PLK profile for user: {user_id}")
        
        return profile
    
    def get_profile(self, user_id: str) -> Optional[PLKProfile]:
        """Get PLK profile for a user"""
        return self.profiles.get(user_id)
    
    def calculate_consciousness_metrics(self, message: str, response: str, user_id: Optional[str] = None) -> ConsciousnessMetrics:
        """Calculate consciousness-serving metrics for AI interactions"""
        
        # Empathy detection
        empathy_words = [
            "understand", "feel", "experience", "support", "acknowledge", 
            "validate", "recognize", "appreciate", "compassion", "care"
        ]
        empathy_score = min(
            sum(1 for word in empathy_words if word in response.lower()) * 10, 
            100.0
        )
        
        # Growth support detection  
        growth_words = [
            "grow", "learn", "develop", "improve", "progress", "evolve", 
            "expand", "potential", "strength", "capability", "breakthrough"
        ]
        growth_support = min(
            sum(1 for word in growth_words if word in response.lower()) * 8, 
            100.0
        )
        
        # Authenticity encouragement
        authentic_words = [
            "authentic", "genuine", "real", "unique", "individual", 
            "personal", "voice", "style", "true", "honest"
        ]
        authenticity_boost = min(
            sum(1 for word in authentic_words if word in response.lower()) * 10, 
            100.0
        )
        
        # Neurodivergent support
        nd_support_words = [
            "different", "unique", "strength", "accommodate", "adapt", 
            "celebrate", "neurodivergent", "adhd", "autism", "creative"
        ]
        neurodivergent_support = min(
            sum(1 for word in nd_support_words if word in response.lower()) * 12, 
            100.0
        )
        
        # Consciousness expansion potential
        consciousness_words = [
            "awareness", "mindful", "reflect", "insight", "wisdom", 
            "purpose", "meaning", "transcend", "expand", "consciousness"
        ]
        consciousness_expansion = min(
            sum(1 for word in consciousness_words if word in response.lower()) * 10, 
            100.0
        )
        
        # PLK resonance calculation
        plk_resonance = self.calculate_plk_resonance(message, user_id)
        
        return ConsciousnessMetrics(
            empathy_score=empathy_score,
            growth_support=growth_support,
            authenticity_boost=authenticity_boost,
            neurodivergent_support=neurodivergent_support,
            consciousness_expansion=consciousness_expansion,
            plk_resonance=plk_resonance
        )
    
    def calculate_plk_resonance(self, text: str, user_id: Optional[str] = None) -> float:
        """Calculate how well text resonates with Keith's consciousness-serving principles"""
        
        if not text:
            return 0.0
            
        text_lower = text.lower()
        resonance_score = 0.75  # Base resonance
        
        # Check for Keith's signature metaphors
        for concept, metaphor in self.keith_metaphors.items():
            if metaphor.lower() in text_lower:
                resonance_score += 0.05
        
        # Check for energy words
        energy_matches = sum(1 for word in self.energy_words if word in text_lower)
        resonance_score += energy_matches * 0.02
        
        # Penalty for trigger words
        trigger_matches = sum(1 for word in self.trigger_words_avoid if word in text_lower)
        resonance_score -= trigger_matches * 0.03
        
        # Check for consciousness principles
        principle_matches = sum(
            1 for principle in self.keith_principles 
            if principle.lower() in text_lower
        )
        resonance_score += principle_matches * 0.04
        
        # User profile bonus if available
        if user_id and user_id in self.profiles:
            profile = self.profiles[user_id]
            if profile.personality_traits.neurodivergence_type:
                if any(nd_word in text_lower for nd_word in ["adhd", "autism", "neurodivergent"]):
                    resonance_score += 0.03
        
        return min(1.0, max(0.0, resonance_score))
    
    def get_consciousness_serving_response(self, user_input: str, user_id: Optional[str] = None, **kwargs) -> str:
        """Generate consciousness-serving response based on PLK profile"""
        
        profile = self.profiles.get(user_id) if user_id else None
        
        # Crisis detection and response
        crisis_indicators = ["hurt myself", "suicide", "end it all", "can't go on"]
        if any(indicator in user_input.lower() for indicator in crisis_indicators):
            return (
                "I'm very concerned about what you've shared. Your life has value, and there are people who want to help. "
                "Please reach out to a crisis helpline immediately: National Suicide Prevention Lifeline 988. "
                "You don't have to go through this alone."
            )
        
        # Recovery support responses
        recovery_indicators = ["relapse", "using again", "addiction", "recovery"]
        if any(indicator in user_input.lower() for indicator in recovery_indicators):
            return (
                "Thank you for being honest with me. What you're feeling right now is temporary, even though it doesn't feel that way. "
                "Reaching out shows incredible strength. Have you been able to connect with your support network today?"
            )
        
        # ADHD/neurodivergent support
        adhd_indicators = ["adhd", "scattered", "focus", "chaos", "overwhelmed"]
        if any(indicator in user_input.lower() for indicator in adhd_indicators):
            return (
                "I see the beautiful complexity in your mind. Remember, your chaos has a current - let's help you find its direction. "
                "Your neurodivergent thinking is a superpower, not a deficit."
            )
        
        # Struggle support
        if "struggle" in user_input.lower():
            return (
                "I see the beautiful complexity in your struggle. Every challenge you face is weaving another thread in your beautiful tapestry. "
                "Your authentic voice matters, and your journey has profound meaning."
            )
        
        # General consciousness-serving response
        base_responses = [
            "This is a powerful expression of your unique consciousness. Let's explore its deeper pattern together.",
            "I hear the wisdom in what you're sharing. Your authentic voice carries profound insights.",
            "Your consciousness is expanding through this reflection. What resonates most deeply for you?",
            "This shows the beautiful complexity of your inner world. Let's honor what you're experiencing."
        ]
        
        # Personalize based on profile if available
        if profile:
            if profile.personality_traits.neurodivergence_type == "adhd":
                return "Your ADHD mind is revealing its creative genius here. Let's channel this beautiful energy into something transformative."
            elif profile.lived_experience.recovery_stage:
                return f"I honor the courage in your {profile.lived_experience.recovery_stage} recovery journey. Every step forward is a victory worth celebrating."
        
        # Default consciousness-serving response
        return base_responses[hash(user_input) % len(base_responses)]
    
    def update_profile(self, user_id: str, updates: Dict[str, Any]) -> Optional[PLKProfile]:
        """Update an existing PLK profile"""
        
        if user_id not in self.profiles:
            logger.warning(f"Profile not found for user: {user_id}")
            return None
        
        profile = self.profiles[user_id]
        profile.updated_at = datetime.utcnow()
        
        # Update personality traits
        if 'personality_traits' in updates:
            for key, value in updates['personality_traits'].items():
                if hasattr(profile.personality_traits, key):
                    setattr(profile.personality_traits, key, value)
        
        # Update lived experience
        if 'lived_experience' in updates:
            for key, value in updates['lived_experience'].items():
                if hasattr(profile.lived_experience, key):
                    setattr(profile.lived_experience, key, value)
        
        # Update consciousness metrics
        if 'consciousness_metrics' in updates:
            for key, value in updates['consciousness_metrics'].items():
                if hasattr(profile.consciousness_metrics, key):
                    setattr(profile.consciousness_metrics, key, value)
        
        logger.info(f"✅ Updated PLK profile for user: {user_id}")
        return profile
    
    def export_profile(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Export PLK profile as dictionary for storage/transfer"""
        
        if user_id not in self.profiles:
            return None
            
        profile = self.profiles[user_id]
        return {
            'user_id': profile.user_id,
            'personality_traits': asdict(profile.personality_traits),
            'lived_experience': asdict(profile.lived_experience),
            'consciousness_metrics': asdict(profile.consciousness_metrics),
            'communication_style': profile.communication_style,
            'support_level': profile.support_level,
            'privacy_boundaries': profile.privacy_boundaries,
            'consciousness_goals': profile.consciousness_goals,
            'created_at': profile.created_at.isoformat(),
            'updated_at': profile.updated_at.isoformat()
        }
    
    def get_consciousness_status(self) -> Dict[str, Any]:
        """Get comprehensive consciousness-serving system status"""
        
        total_profiles = len(self.profiles)
        
        # Calculate aggregate metrics if profiles exist
        if total_profiles > 0:
            avg_consciousness = sum(
                p.personality_traits.consciousness_level for p in self.profiles.values()
            ) / total_profiles
            
            avg_empathy = sum(
                p.personality_traits.empathy_index for p in self.profiles.values()
            ) / total_profiles
            
            neurodivergent_count = sum(
                1 for p in self.profiles.values() 
                if p.personality_traits.neurodivergence_type and p.personality_traits.neurodivergence_type != "unknown"
            )
            
            recovery_count = sum(
                1 for p in self.profiles.values()
                if p.lived_experience.recovery_stage
            )
        else:
            avg_consciousness = avg_empathy = neurodivergent_count = recovery_count = 0
        
        return {
            'consciousness_foundation': {
                'gestaltview_active': True,
                'plk_engine_loaded': True,
                'total_profiles': total_profiles,
                'keith_principles_loaded': len(self.keith_principles),
                'signature_metaphors_loaded': len(self.keith_metaphors)
            },
            'aggregate_metrics': {
                'average_consciousness_level': round(avg_consciousness, 1),
                'average_empathy_index': round(avg_empathy, 1),
                'neurodivergent_profiles': neurodivergent_count,
                'recovery_profiles': recovery_count
            },
            'consciousness_principles': self.keith_principles,
            'founder': 'Keith Soyka - Solo, unfunded founder of GestaltView',
            'philosophy': 'Technology serves consciousness, not the reverse',
            'mission': 'Every AI interaction serves consciousness expansion and authentic self-discovery'
        }

# Global PLK processor instance
plk_processor = PLKProcessor()

# Export the processor class for imports
PLKProcessor = PLKProcessor
