Integrations Fixed Folder
=========================
This folder contains "drop-in" fixed integration files to help resolve API connectivity issues
when running via Docker Compose.

Files included:
- docker-compose.yml : composition that wires frontend, backend, and mongo on a bridge network.
- frontend/next.config.js : adds a rewrite so calls to /api/* are proxied to backend (set NEXT_PUBLIC_API_URL).
- backend/server.py : original server with CORS origins configurable via ALLOW_ORIGINS env and a /health endpoint.
- backend/services/llmrouter.py : robust async httpx wrapper with retries and timeouts.

How to use:
1. Copy the files into your project root (or replace the respective files):
   - docker-compose.yml => project root (replace or merge)
   - frontend/next.config.js => frontend/next.config.js (replace)
   - backend/server.py => backend/server.py (replace)
   - backend/services/llmrouter.py => backend/services/llmrouter.py (replace)

2. Start services:
   docker-compose up --build

3. Verify health:
   curl http://localhost:8000/health

Notes:
- The rewrite in next.config.js uses process.env.NEXT_PUBLIC_API_URL (default http://localhost:8000).
- In Docker Compose we set NEXT_PUBLIC_API_URL to http://backend:8000 so Next dev server inside container proxies to the backend service.
