# README_TESTING

This testing suite provides both **mock** and **live** test modes for your FastAPI backend and frontend TypeScript code.

## Requirements

Install Python test requirements:
```
pip install -r requirements-test.txt
```

### Mock mode (fast)
Mocks MongoDB with `mongomock` and does not call external LLM APIs.

Run:
```
pytest -m mock -q
```

### Live mode (integration)
Runs tests against your real services. Provide environment variables (or a .env file) for:
- MONGODB_URI
- Any LLM API keys required by your services (e.g., OPENAI_API_KEY)

Run:
```
pytest -m live -q
```

### Frontend tests
A basic Jest setup is included under `frontend/` using `ts-jest`. Run:
```
cd frontend
npm install
npm test
```

### Notes
- The tests are intentionally conservative and best-effort: they attempt to import the application's modules from several possible locations.
- If your DatabaseService uses a different interface, update `tests/conftest.py` to patch the connection appropriately.
- If you'd like, I can extend tests to assert exact payloads and responses for each route once you confirm route schemas.
