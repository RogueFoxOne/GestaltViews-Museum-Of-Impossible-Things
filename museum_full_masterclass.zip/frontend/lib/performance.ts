// NEW FILE: Performance monitoring for consciousness-serving optimization
export class MuseumPerformanceMonitor {
  private static instance: MuseumPerformanceMonitor
  
  public static getInstance(): MuseumPerformanceMonitor {
    if (!MuseumPerformanceMonitor.instance) {
      MuseumPerformanceMonitor.instance = new MuseumPerformanceMonitor()
    }
    return MuseumPerformanceMonitor.instance
  }

  public trackEmberPerformance(action: string, duration?: number) {
    if (typeof window !== 'undefined' && 'performance' in window) {
      window.performance.mark(`museum-ember-${action}`)
      
      if (duration && duration > 16) { // More than one frame
        console.warn(`🔥 Ember effect ${action} took ${duration}ms - consider optimizing`)
      }
    }
  }

  public trackUserInteraction(element: string, type: string) {
    if (typeof window !== 'undefined') {
      // Track consciousness-serving interactions
      console.log(`🎯 User interaction: ${type} on ${element}`)
    }
  }
}
