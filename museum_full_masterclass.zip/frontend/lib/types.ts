
export type Message = {
  id: string;
  content: string;
  type: 'user' | 'ai';
  resonanceScore?: number;
};

export type ResumeData = {
  summary: string;
  skills: string[];
  experience: {
    title: string;
    bulletPoints: string[];
  }[];
};

export type AiResponse = {
  response: string;
  extractedSkills: string[];
  resonanceScore: number;
  newExperienceBullet?: string;
};
