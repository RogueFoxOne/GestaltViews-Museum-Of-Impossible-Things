// lib/api/showcaseClient.ts
// API client for Museum of Impossible Things Live Showcases

export interface ConsciousnessState {
  energy: number;
  mood: string;
  flow: string;
  companion?: string;
}

export interface ShowcaseRequest {
  message: string;
  app_type: 'vibecoder' | 'resume-rockstar' | 'symbiocoder';
  consciousness_state?: ConsciousnessState;
  provider?: string;
  max_tokens?: number;
  temperature?: number;
}

export interface ShowcaseResponse {
  response: string;
  code_block?: string;
  extracted_skills: string[];
  metrics: Record<string, any>;
  resonance_score: number;
}

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export class ShowcaseAPIClient {
  private baseURL: string;

  constructor(baseURL: string = API_BASE_URL) {
    this.baseURL = baseURL;
  }

  async generateResponse(request: ShowcaseRequest): Promise<ShowcaseResponse> {
    try {
      const response = await fetch(`${this.baseURL}/api/showcase/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Failed to generate response');
      }

      return await response.json();
    } catch (error) {
      console.error('ShowcaseAPIClient error:', error);
      throw error;
    }
  }

  async getAvailableProviders() {
    const response = await fetch(`${this.baseURL}/api/showcase/providers`);
    return await response.json();
  }

  async checkHealth() {
    const response = await fetch(`${this.baseURL}/api/showcase/health`);
    return await response.json();
  }
}

// Singleton instance
export const showcaseAPI = new ShowcaseAPIClient();

// Helper functions for each app

export async function sendVibeCoderMessage(
  message: string,
  consciousnessState: ConsciousnessState
): Promise<ShowcaseResponse> {
  return showcaseAPI.generateResponse({
    message,
    app_type: 'vibecoder',
    consciousness_state: consciousnessState,
    provider: 'pplx_ai',
    max_tokens: 500,
  });
}

export async function sendResumeRockstarMessage(
  message: string
): Promise<ShowcaseResponse> {
  return showcaseAPI.generateResponse({
    message,
    app_type: 'resume-rockstar',
    provider: 'pplx_ai',
    max_tokens: 400,
  });
}

export async function sendSymbioCoderMessage(
  message: string,
  consciousnessState: ConsciousnessState
): Promise<ShowcaseResponse> {
  return showcaseAPI.generateResponse({
    message,
    app_type: 'symbiocoder',
    consciousness_state: consciousnessState,
    provider: 'ollama_codellama',
    max_tokens: 600,
  });
}
