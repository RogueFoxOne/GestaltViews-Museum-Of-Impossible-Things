// lib/universal-voice-integration.ts
// Museum of Impossible Things - Universal Voice Integration
// Complete file with correct import paths

import { useVoiceChat } from '@/hooks/useVoiceChat';
import { useRouter } from 'next/navigation';

export function useUniversalVoiceCommands() {
  const { isListening, startListening, stopListening, transcript } = useVoiceChat();
  const router = useRouter();

  const processVoiceCommand = (transcript: string) => {
    const lower = transcript.toLowerCase();

    // Navigation commands
    if (lower.includes('go to') || lower.includes('show me') || lower.includes('open')) {
      if (lower.includes('journal')) {
        router.push('/recovery?view=journal');
      } else if (lower.includes('chat') || lower.includes('ai support')) {
        router.push('/recovery?view=chat');
      } else if (lower.includes('dashboard') || lower.includes('home')) {
        router.push('/recovery?view=dashboard');
      } else if (lower.includes('exhibits')) {
        router.push('/exhibits');
      }
    }

    // Quick actions
    if (lower.includes('need help') || lower.includes('crisis')) {
      // Trigger crisis resources
      window.dispatchEvent(new CustomEvent('showCrisisResources'));
    }

    return transcript;
  };

  return {
    isListening,
    startListening,
    stopListening,
    transcript,
    processVoiceCommand,
  };
}
